# main.py

from data_summary import math_ops, visuals

# Sample dataset
data = [12, 15, 12, 18, 20, 15, 15, 18, 22]

print("Data:", data)

# Use math_ops functions
mean_val = math_ops.calculate_mean(data)
median_val = math_ops.calculate_median(data)
mode_val = math_ops.calculate_mode(data)

print(f"Mean: {mean_val}")
print(f"Median: {median_val}")
print(f"Mode: {mode_val}")

# Example data for visualization
categories = ['A', 'B', 'C', 'D']
values = [10, 20, 15, 25]

# Use visuals function
visuals.draw_bar_chart(categories, values)
