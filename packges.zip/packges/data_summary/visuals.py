# visuals.py

import matplotlib.pyplot as plt

def draw_bar_chart(categories, values):
    """Draw a simple bar chart"""
    plt.bar(categories, values, color='skyblue')
    plt.xlabel("Categories")
    plt.ylabel("Values")
    plt.title("Bar Chart")
    plt.show()
