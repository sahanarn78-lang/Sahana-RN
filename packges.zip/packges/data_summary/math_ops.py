# math_ops.py

from statistics import mean, median, mode

def calculate_mean(data):
    """Return the mean of a list of numbers"""
    return mean(data)

def calculate_median(data):
    """Return the median of a list of numbers"""
    return median(data)

def calculate_mode(data):
    """Return the mode of a list of numbers"""
    return mode(data)
