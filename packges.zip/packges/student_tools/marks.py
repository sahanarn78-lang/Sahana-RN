# marks.py

def calculate_total(marks):
    return sum(marks)

def calculate_average(marks):
    if len(marks) == 0:
        return 0
    return sum(marks) / len(marks)
