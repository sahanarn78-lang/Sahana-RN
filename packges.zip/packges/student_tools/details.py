# details.py

def display_details(name, course):
    print(f"Student Name: {name}")
    print(f"Course: {course}")
