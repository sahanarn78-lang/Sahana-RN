from student_tools import marks, grades, details

student_name = "Sahana"
course_name = "Computer Science"
marks_list = [85, 90, 78, 92, 88]

details.display_details(student_name, course_name)

total = marks.calculate_total(marks_list)
average = marks.calculate_average(marks_list)
grade = grades.assign_grade(average)

print(f"Total Marks: {total}")
print(f"Average Marks: {average:.2f}")
print(f"Grade: {grade}")
