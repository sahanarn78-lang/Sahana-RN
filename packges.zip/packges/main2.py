import pandas as pd
from sales_tools import cleaning, report

data = {
    'Product': ['Laptop', 'Phone', 'Tablet', 'Headphones', None],
    'Sales': [1200, 800, 650, 300, None]
}

df = pd.DataFrame(data)

print("Original Data:")
print(df)


cleaned_df = cleaning.remove_empty_rows(df)

print("\nCleaned Data:")
print(cleaned_df)


report.sales_summary(cleaned_df)
