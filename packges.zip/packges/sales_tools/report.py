def sales_summary(df):
    total_sales = df['Sales'].sum()
    average_sales = df['Sales'].mean()
    
    print("------ Sales Report ------")
    print(f"Total Sales: {total_sales}")
    print(f"Average Sales: {average_sales:.2f}")
