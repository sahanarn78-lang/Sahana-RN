import pandas as pd

def remove_empty_rows(df):

    cleaned_df = df.dropna()
    return cleaned_df
